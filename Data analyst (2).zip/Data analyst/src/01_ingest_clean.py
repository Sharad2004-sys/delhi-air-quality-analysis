"""
Step 1: Ingest + clean Delhi air-quality data.

Usage
-----
Real data:  put CPCB station CSVs in data/raw/stations/  (one file per station)
            and a weather CSV at data/raw/weather_daily.csv, then run:
                python src/01_ingest_clean.py
Demo data:  python src/01_ingest_clean.py --demo
            (synthetic, with realistic faults injected, so the pipeline runs end to end)

Expected raw station columns (rename in COLUMN_MAP if your export differs):
    datetime, PM2.5, PM10, NO2, SO2, CO, O3        (hourly, station name = file name)
Expected weather columns:
    date, temp_c, humidity_pct, wind_kmh, rain_mm
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

RAW = Path("data/raw")
OUT = Path("data/processed")
OUT.mkdir(parents=True, exist_ok=True)

POLLUTANTS = ["pm25", "pm10", "no2", "so2", "co", "o3"]
COLUMN_MAP = {"PM2.5": "pm25", "PM10": "pm10", "NO2": "no2", "SO2": "so2", "CO": "co", "O3": "o3"}

DIWALI = ["2021-11-04", "2022-10-24", "2023-11-12", "2024-11-01", "2025-10-20"]

# Indian national AQI breakpoints for 24-h PM2.5 (ug/m3)
PM25_BINS = [0, 30, 60, 90, 120, 250, np.inf]
PM25_LABELS = ["Good", "Satisfactory", "Moderate", "Poor", "Very Poor", "Severe"]

log = {}  # every cleaning decision and how many rows it touched


def record(step, **kw):
    log[step] = kw
    print(f"[clean] {step}: {kw}")


# ----------------------------------------------------------------------------
# Demo data generator (only used with --demo)
# ----------------------------------------------------------------------------
def make_demo(seed=42):
    rng = np.random.default_rng(seed)
    days = pd.date_range("2021-01-01", "2025-12-31", freq="D")
    doy = days.dayofyear.values

    def wrap(x):  # circular distance in days
        return (x + 183) % 366 - 183

    season = (55
              + 135 * np.exp(-(wrap(doy - 320) / 38) ** 2)   # Oct-Nov (stubble + festivals + inversion)
              + 70 * np.exp(-(wrap(doy - 10) / 30) ** 2)     # Dec-Jan cold, still air
              - 25 * np.exp(-(wrap(doy - 215) / 35) ** 2))   # monsoon wash-out

    temp = 25 - 11 * np.cos(2 * np.pi * (doy - 20) / 365) + rng.normal(0, 2, len(days))
    humidity = np.clip(55 + 20 * np.sin(2 * np.pi * (doy - 150) / 365) + rng.normal(0, 10, len(days)), 15, 100)
    wind = np.clip(9 - 2.5 * np.exp(-(wrap(doy - 335) / 60) ** 2) + rng.normal(0, 3, len(days)), 1, 25)
    rain = np.where((rng.random(len(days)) < 0.12 + 0.25 * np.exp(-(wrap(doy - 205) / 40) ** 2)),
                    rng.exponential(8, len(days)), 0.0)
    weather = pd.DataFrame({"date": days, "temp_c": temp.round(1), "humidity_pct": humidity.round(0),
                            "wind_kmh": wind.round(1), "rain_mm": rain.round(1)})

    diwali_boost = np.zeros(len(days))
    for d in pd.to_datetime(DIWALI):
        delta = (days - d).days.values
        diwali_boost += np.where((delta >= 0) & (delta <= 3), 70 * np.exp(-delta / 2.5), 0)

    base = season * np.exp(-0.06 * (wind - 9)) * np.where(rain > 2, 0.6, 1.0)
    base = base * np.where(days.dayofweek >= 5, 0.95, 1.0) + diwali_boost

    stations = {"Anand Vihar": 1.30, "Rohini": 1.15, "Dwarka": 1.00, "ITO": 1.05,
                "RK Puram": 0.92, "Punjabi Bagh": 1.10, "Okhla": 1.20, "Lodhi Road": 0.80}
    hourly_shape = np.array([1.10, 1.12, 1.10, 1.05, 1.0, 1.0, 1.05, 1.12, 1.15, 1.05, 0.9, 0.8,
                             0.72, 0.68, 0.68, 0.72, 0.8, 0.92, 1.05, 1.15, 1.2, 1.2, 1.18, 1.14])

    stn_dir = RAW / "stations"
    stn_dir.mkdir(parents=True, exist_ok=True)
    idx = pd.date_range("2021-01-01", "2025-12-31 23:00", freq="h")
    day_pos = (idx.normalize() - days[0]).days.values
    for name, mult in stations.items():
        pm25 = base[day_pos] * mult * hourly_shape[idx.hour] * rng.lognormal(0, 0.15, len(idx))
        df = pd.DataFrame({"datetime": idx,
                           "PM2.5": pm25,
                           "PM10": pm25 * rng.uniform(1.5, 2.2, len(idx)),
                           "NO2": 25 + 0.25 * pm25 + rng.normal(0, 6, len(idx)),
                           "SO2": np.abs(8 + rng.normal(0, 3, len(idx))),
                           "CO": np.abs(1.0 + 0.004 * pm25 + rng.normal(0, 0.3, len(idx))),
                           "O3": np.abs(30 + rng.normal(0, 12, len(idx)))})
        # --- inject realistic faults -------------------------------------------
        n = len(df)
        for _ in range(12):  # long sensor outages
            s = rng.integers(0, n - 800); df.loc[s:s + rng.integers(30, 700), POLLUTANTS_RAW] = np.nan
        for _ in range(8):   # stuck sensor (repeated value)
            s = rng.integers(0, n - 100); df.loc[s:s + rng.integers(26, 90), "PM2.5"] = df.loc[s, "PM2.5"]
        bad = rng.choice(n, 150, replace=False); df.loc[bad[:75], "PM2.5"] = -999   # error code
        df.loc[bad[75:], "PM2.5"] = 3000                                          # impossible spike
        df = pd.concat([df, df.sample(300, random_state=1)])                      # duplicate rows
        df.sample(frac=1, random_state=2).to_csv(stn_dir / f"{name}.csv", index=False)
    weather.to_csv(RAW / "weather_daily.csv", index=False)
    print(f"[demo] wrote {len(stations)} station files + weather to {RAW}/")


POLLUTANTS_RAW = ["PM2.5", "PM10", "NO2", "SO2", "CO", "O3"]


# ----------------------------------------------------------------------------
# Cleaning
# ----------------------------------------------------------------------------
def load_stations():
    frames = []
    for f in sorted((RAW / "stations").glob("*.csv")):
        d = pd.read_csv(f).rename(columns=COLUMN_MAP)
        d["station"] = f.stem
        d["datetime"] = pd.to_datetime(d["datetime"], errors="coerce")
        frames.append(d[["station", "datetime"] + POLLUTANTS])
    df = pd.concat(frames, ignore_index=True)
    record("raw_load", rows=len(df), stations=df["station"].nunique())
    return df


def clean_hourly(df):
    n0 = len(df)
    df = df.dropna(subset=["datetime"])
    record("drop_bad_timestamps", rows_removed=n0 - len(df))

    n0 = len(df)
    df = df.sort_values(["station", "datetime"]).drop_duplicates(["station", "datetime"], keep="first")
    record("drop_duplicate_station_timestamps", rows_removed=n0 - len(df))

    # Physically impossible / error-code values -> NaN (not dropped, so the hour stays visible as missing)
    limits = {"pm25": (0, 1000), "pm10": (0, 1500), "no2": (0, 500), "so2": (0, 500), "co": (0, 50), "o3": (0, 500)}
    for col, (lo, hi) in limits.items():
        bad = (df[col] <= lo) | (df[col] > hi)
        record(f"invalid_{col}_set_nan", values_affected=int(bad.sum()))
        df.loc[bad, col] = np.nan

    # PM2.5 cannot exceed PM10 (PM2.5 is a subset); allow 10% tolerance for sensor error
    inconsistent = df["pm25"] > df["pm10"] * 1.1
    record("pm25_gt_pm10_set_nan", values_affected=int(inconsistent.sum()))
    df.loc[inconsistent, "pm25"] = np.nan

    # Stuck sensor: identical PM2.5 reading for >= 24 consecutive hours
    def stuck_mask(s, run=24):
        grp = (s != s.shift()).cumsum()
        return s.groupby(grp).transform("size").ge(run) & s.notna()

    total_stuck = 0
    for st, g in df.groupby("station"):
        m = stuck_mask(g["pm25"])
        df.loc[g.index[m], "pm25"] = np.nan
        total_stuck += int(m.sum())
    record("stuck_sensor_pm25_set_nan", values_affected=total_stuck)

    # Fill short gaps only (<= 3 hours); long outages stay missing on purpose
    filled = 0
    parts = []
    for st, g in df.groupby("station"):
        g = g.set_index("datetime").asfreq("h")
        g["station"] = st
        before = g[POLLUTANTS].isna().sum().sum()
        g[POLLUTANTS] = g[POLLUTANTS].interpolate(limit=3, limit_area="inside")
        filled += int(before - g[POLLUTANTS].isna().sum().sum())
        parts.append(g.reset_index())
    df = pd.concat(parts, ignore_index=True)
    record("short_gap_interpolation_le_3h", values_filled=filled)
    return df


def to_daily(df):
    df["date"] = df["datetime"].dt.normalize()
    agg = df.groupby(["station", "date"]).agg(**{c: (c, "mean") for c in POLLUTANTS},
                                              valid_hours_pm25=("pm25", "count")).reset_index()
    n0 = len(agg)
    agg = agg[agg["valid_hours_pm25"] >= 16].copy()  # CPCB-style: need >= 16 valid hours for a valid day
    record("daily_requires_16_valid_hours", station_days_dropped=n0 - len(agg), station_days_kept=len(agg))
    agg["pm25_category"] = pd.cut(agg["pm25"], PM25_BINS, labels=PM25_LABELS, right=True)
    return agg


def build_dims(daily):
    w = pd.read_csv(RAW / "weather_daily.csv", parse_dates=["date"])
    dates = pd.DataFrame({"date": pd.date_range(daily["date"].min(), daily["date"].max())})
    dates["date_key"] = dates["date"].dt.strftime("%Y%m%d").astype(int)
    dates["year"] = dates["date"].dt.year
    dates["month"] = dates["date"].dt.month
    dates["month_name"] = dates["date"].dt.month_name()
    dates["day_of_week"] = dates["date"].dt.day_name()
    dates["is_weekend"] = (dates["date"].dt.dayofweek >= 5).astype(int)
    dates["season"] = dates["month"].map(lambda m: "Winter" if m in (12, 1, 2) else "Summer" if m in (3, 4, 5, 6)
                                         else "Monsoon" if m in (7, 8, 9) else "Post-monsoon")
    dates["is_stubble_season"] = dates["month"].isin([10, 11]).astype(int)
    diw = pd.to_datetime(DIWALI)
    dates["is_diwali_window"] = dates["date"].apply(lambda d: int(any(0 <= (d - x).days <= 3 or -3 <= (d - x).days < 0 for x in diw)))

    stations = pd.DataFrame({"station": sorted(daily["station"].unique())})
    stations["station_key"] = range(1, len(stations) + 1)

    fact = (daily.merge(stations, on="station")
                 .assign(date_key=lambda d: d["date"].dt.strftime("%Y%m%d").astype(int)))
    fact = fact[["station_key", "date_key"] + POLLUTANTS + ["valid_hours_pm25", "pm25_category"]]
    weather = w.assign(date_key=w["date"].dt.strftime("%Y%m%d").astype(int)).drop(columns="date")
    return fact, stations, dates, weather


def main(demo):
    if demo:
        make_demo()
    daily = to_daily(clean_hourly(load_stations()))
    fact, dim_station, dim_date, dim_weather = build_dims(daily)
    fact.to_csv(OUT / "fact_readings.csv", index=False)
    dim_station.to_csv(OUT / "dim_station.csv", index=False)
    dim_date.to_csv(OUT / "dim_date.csv", index=False)
    dim_weather.to_csv(OUT / "dim_weather.csv", index=False)
    json.dump(log, open(OUT / "cleaning_log.json", "w"), indent=2)
    print(f"\nWrote tables to {OUT}/  (fact rows: {len(fact):,})")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--demo", action="store_true", help="generate synthetic data first")
    main(ap.parse_args().demo)
