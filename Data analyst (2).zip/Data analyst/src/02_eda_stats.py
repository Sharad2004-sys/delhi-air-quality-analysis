"""
Step 2: EDA + statistical tests on the processed tables.
Run after 01_ingest_clean.py:   python src/02_eda_stats.py

Design note: tests run on the CITY-DAY mean (average across stations), not on station-days.
Stations on the same day are highly correlated, so treating them as independent samples
would overstate significance (pseudo-replication).
"""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import statsmodels.formula.api as smf
from scipy import stats
from statsmodels.stats.stattools import durbin_watson

P = Path("data/processed")
FIG = Path("reports/figures")
FIG.mkdir(parents=True, exist_ok=True)
sns.set_theme(style="whitegrid")

fact = pd.read_csv(P / "fact_readings.csv")
stn = pd.read_csv(P / "dim_station.csv")
dte = pd.read_csv(P / "dim_date.csv", parse_dates=["date"])
wx = pd.read_csv(P / "dim_weather.csv")

df = fact.merge(stn, on="station_key").merge(dte, on="date_key").merge(wx, on="date_key", how="left")
city = (df.groupby("date_key").agg(pm25=("pm25", "mean"), n_stations=("station", "nunique")).reset_index()
          .merge(dte, on="date_key").merge(wx, on="date_key", how="left"))
city = city[city["n_stations"] >= 4].sort_values("date").reset_index(drop=True)  # need decent coverage
results = {"city_days": len(city)}

# ---------------------------------------------------------------- descriptive
monthly = city.groupby("month")["pm25"].agg(["mean", "median", "max"]).round(1)
print("\nMonthly PM2.5 (city mean):\n", monthly)
by_station = df.groupby("station")["pm25"].mean().sort_values(ascending=False).round(1)
print("\nMean PM2.5 by station:\n", by_station)
results["worst_month"] = int(monthly["mean"].idxmax())
results["worst_station"] = by_station.index[0]

fig, ax = plt.subplots(figsize=(8, 4))
sns.barplot(x=monthly.index, y=monthly["mean"], color="#c0392b", ax=ax)
ax.set(xlabel="Month", ylabel="Mean PM2.5 (ug/m3)", title="Seasonality: Delhi city-mean PM2.5")
fig.tight_layout(); fig.savefig(FIG / "monthly_pm25.png", dpi=150); plt.close(fig)

heat = df.assign(year=df["year"]).pivot_table(index="station", columns="month", values="pm25", aggfunc="mean")
fig, ax = plt.subplots(figsize=(9, 4.5))
sns.heatmap(heat, cmap="rocket_r", annot=True, fmt=".0f", ax=ax)
ax.set_title("Mean PM2.5 by station and month")
fig.tight_layout(); fig.savefig(FIG / "station_month_heatmap.png", dpi=150); plt.close(fig)

# ---------------------------------------------------------------- test 1: Diwali window
# Naive comparison (window vs rest of Oct15-Nov30) is confounded: PM2.5 trends up through the season,
# so late-Oct days look "clean" regardless of Diwali. Use a LOCAL baseline instead: each day's PM2.5
# divided by the centred 21-day rolling median, then compare window days to non-window days.
city["pm25_rel"] = city["pm25"] / city["pm25"].rolling(21, center=True, min_periods=15).median()
season_mask = ((city["month"] == 10) & (city["date"].dt.day >= 15)) | (city["month"] == 11)
sub = city[season_mask].dropna(subset=["pm25_rel"])
a, b = sub[sub["is_diwali_window"] == 1]["pm25_rel"], sub[sub["is_diwali_window"] == 0]["pm25_rel"]
u = stats.mannwhitneyu(a, b, alternative="greater")
naive = stats.mannwhitneyu(city[season_mask & (city["is_diwali_window"] == 1)]["pm25"],
                           city[season_mask & (city["is_diwali_window"] == 0)]["pm25"], alternative="greater")
results["diwali"] = {"n_window": len(a), "n_other": len(b),
                     "median_ratio_to_local_baseline_window": round(float(a.median()), 3),
                     "median_ratio_to_local_baseline_other": round(float(b.median()), 3),
                     "mannwhitney_p_local_baseline": float(u.pvalue),
                     "mannwhitney_p_naive_for_comparison": float(naive.pvalue),
                     "rank_biserial": round(2 * u.statistic / (len(a) * len(b)) - 1, 3)}
print("\nDiwali window (local-baseline test):", results["diwali"])
print("  caveat: Diwali coincides with stubble burning + cooling temps, so this is an association, not causation.")

# ---------------------------------------------------------------- test 2: weekday vs weekend
wk = city[city["is_weekend"] == 0]["pm25"]; we = city[city["is_weekend"] == 1]["pm25"]
u2 = stats.mannwhitneyu(wk, we, alternative="two-sided")
results["weekend"] = {"median_weekday": round(wk.median(), 1), "median_weekend": round(we.median(), 1),
                      "mannwhitney_p": float(u2.pvalue)}
print("\nWeekday vs weekend:", results["weekend"])

# ---------------------------------------------------------------- correlations
cols = ["pm25", "wind_kmh", "humidity_pct", "temp_c", "rain_mm"]
corr = city[cols].corr(method="spearman").round(2)
print("\nSpearman correlation:\n", corr)
fig, ax = plt.subplots(figsize=(5.5, 4.5))
sns.heatmap(corr, annot=True, cmap="coolwarm", center=0, ax=ax)
fig.tight_layout(); fig.savefig(FIG / "correlation.png", dpi=150); plt.close(fig)
results["spearman_pm25_wind"] = float(corr.loc["pm25", "wind_kmh"])

# ---------------------------------------------------------------- regression (log PM2.5)
city["log_pm25"] = np.log(city["pm25"])
city["rain_flag"] = (city["rain_mm"] > 2).astype(int)
weather_only = smf.ols("log_pm25 ~ wind_kmh + humidity_pct + temp_c + rain_flag", data=city).fit()
full = smf.ols("log_pm25 ~ wind_kmh + humidity_pct + temp_c + rain_flag + C(month) + is_weekend + is_diwali_window",
               data=city).fit(cov_type="HAC", cov_kwds={"maxlags": 7})  # robust to autocorrelation
results["regression"] = {
    "r2_weather_only": round(weather_only.rsquared, 3),
    "r2_with_season_and_events": round(full.rsquared, 3),
    "wind_pct_change_per_kmh": round((np.exp(full.params["wind_kmh"]) - 1) * 100, 2),
    "diwali_pct_effect": round((np.exp(full.params["is_diwali_window"]) - 1) * 100, 1),
    "durbin_watson_weather_only": round(durbin_watson(weather_only.resid), 2),
}
print("\nRegression summary:", json.dumps(results["regression"], indent=2))
print("  Durbin-Watson well below 2 => residual autocorrelation => naive p-values too optimistic (HAC used).")

# ---------------------------------------------------------------- severe-day finding
city["severe"] = (city["pm25"] > 250).astype(int)
calm = city["wind_kmh"] < city["wind_kmh"].quantile(0.25)
results["severe_days"] = {
    "total": int(city["severe"].sum()),
    "share_in_oct_dec": round(city.loc[city["month"].isin([10, 11, 12]), "severe"].sum() / max(city["severe"].sum(), 1), 3),
    "share_on_calm_days_bottom_quartile_wind": round(city.loc[calm, "severe"].sum() / max(city["severe"].sum(), 1), 3),
}
print("\nSevere-day concentration:", results["severe_days"])

json.dump(results, open("reports/results.json", "w"), indent=2, default=str)
print("\nSaved reports/results.json and figures to", FIG)
