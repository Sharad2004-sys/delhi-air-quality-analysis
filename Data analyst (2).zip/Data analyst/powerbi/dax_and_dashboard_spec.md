# Power BI build guide

## Model
Import the four tables (SQL Server connector, or the CSVs in `data/processed/`).
Relationships (all many-to-one, single direction):
- `fact_readings[station_key]` → `dim_station[station_key]`
- `fact_readings[date_key]` → `dim_date[date_key]`
- `dim_weather[date_key]` → `dim_date[date_key]` (one-to-one is fine)

Mark `dim_date[date]` as the date table. Sort `month_name` by `month`.

## DAX measures

```DAX
Avg PM2.5 = AVERAGE ( fact_readings[pm25] )

Valid Station Days = COUNTROWS ( FILTER ( fact_readings, NOT ISBLANK ( fact_readings[pm25] ) ) )

Severe Days =
CALCULATE ( DISTINCTCOUNT ( fact_readings[date_key] ), fact_readings[pm25] > 250 )

Severe Station-Days % =
DIVIDE ( CALCULATE ( [Valid Station Days], fact_readings[pm25] > 250 ), [Valid Station Days] )

Avg PM2.5 LY =
CALCULATE ( [Avg PM2.5], SAMEPERIODLASTYEAR ( dim_date[date] ) )

PM2.5 YoY % = DIVIDE ( [Avg PM2.5] - [Avg PM2.5 LY], [Avg PM2.5 LY] )

PM2.5 7D Rolling Avg =
AVERAGEX (
    DATESINPERIOD ( dim_date[date], MAX ( dim_date[date] ), -7, DAY ),
    [Avg PM2.5]
)

% of Days in Category =
DIVIDE (
    [Valid Station Days],
    CALCULATE ( [Valid Station Days], ALL ( fact_readings[pm25_category] ) )
)

Worst Month =
VAR t = ADDCOLUMNS ( VALUES ( dim_date[month_name] ), "@v", [Avg PM2.5] )
RETURN MAXX ( TOPN ( 1, t, [@v], DESC ), dim_date[month_name] )

Diwali Uplift % =
VAR inW = CALCULATE ( [Avg PM2.5], dim_date[is_diwali_window] = TRUE () )
VAR out = CALCULATE ( [Avg PM2.5], dim_date[is_diwali_window] = FALSE (), dim_date[month] IN { 10, 11 } )
RETURN DIVIDE ( inW - out, out )   -- naive; say so on the page (see Python analysis for the controlled estimate)
```

## Pages

**1. Executive summary**: KPI cards (Avg PM2.5, Severe Days, Worst Month, YoY %), line chart of monthly PM2.5 by year, stacked 100% column of AQI category share by year. Slicers: year, station.

**2. Station drill-down**: map (needs station lat/long: add to `dim_station`), matrix heatmap of station × month with conditional formatting, hour-of-day pattern if you keep hourly data (add an hourly table).

**3. Driver analysis**: scatter of wind vs PM2.5, box-style comparison of severe vs non-severe weather, event impact (Diwali / weekend / stubble season). Add a text box stating the regression result from `reports/results.json`.

Design rules: one colour scale for AQI categories on every page, titles that state the takeaway ("Severe days cluster in Nov"), not just the metric name.
