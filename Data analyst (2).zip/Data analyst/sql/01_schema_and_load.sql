-- SQL Server: star schema for Delhi air-quality analysis
-- Load order: dim_station, dim_date, dim_weather, fact_readings (CSV files from data/processed/)

CREATE DATABASE delhi_aqi;
GO
USE delhi_aqi;
GO

CREATE TABLE dim_station (
    station_key INT          NOT NULL PRIMARY KEY,
    station     VARCHAR(60)  NOT NULL UNIQUE
);

CREATE TABLE dim_date (
    date_key          INT         NOT NULL PRIMARY KEY,   -- yyyymmdd
    [date]            DATE        NOT NULL UNIQUE,
    [year]            SMALLINT    NOT NULL,
    [month]           TINYINT     NOT NULL,
    month_name        VARCHAR(10) NOT NULL,
    day_of_week       VARCHAR(10) NOT NULL,
    is_weekend        BIT         NOT NULL,
    season            VARCHAR(15) NOT NULL,
    is_stubble_season BIT         NOT NULL,
    is_diwali_window  BIT         NOT NULL
);

CREATE TABLE dim_weather (
    date_key     INT          NOT NULL PRIMARY KEY REFERENCES dim_date(date_key),
    temp_c       DECIMAL(5,1) NULL,
    humidity_pct DECIMAL(5,1) NULL,
    wind_kmh     DECIMAL(5,1) NULL,
    rain_mm      DECIMAL(6,1) NULL
);

CREATE TABLE fact_readings (
    station_key      INT          NOT NULL REFERENCES dim_station(station_key),
    date_key         INT          NOT NULL REFERENCES dim_date(date_key),
    pm25             DECIMAL(7,2) NULL,
    pm10             DECIMAL(7,2) NULL,
    no2              DECIMAL(7,2) NULL,
    so2              DECIMAL(7,2) NULL,
    co               DECIMAL(7,3) NULL,
    o3               DECIMAL(7,2) NULL,
    valid_hours_pm25 TINYINT      NULL,
    pm25_category    VARCHAR(15)  NULL,
    CONSTRAINT pk_fact PRIMARY KEY (station_key, date_key)
);
CREATE INDEX ix_fact_date ON fact_readings(date_key) INCLUDE (pm25);

-- Load (adjust the path). Easiest alternative: SSMS > Tasks > Import Flat File.
-- BULK INSERT fact_readings FROM 'C:\data\fact_readings.csv'
-- WITH (FIRSTROW = 2, FIELDTERMINATOR = ',', ROWTERMINATOR = '0x0a', TABLOCK);
-- Note: pandas writes empty strings for NULLs; Import Flat File handles that, BULK INSERT needs a staging table.
