USE delhi_aqi;
GO

-- Q1. Rolling 7-day average PM2.5 per station
SELECT s.station, d.[date], f.pm25,
       AVG(f.pm25) OVER (PARTITION BY f.station_key ORDER BY d.[date]
                         ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS pm25_7d_avg
FROM fact_readings f
JOIN dim_station s ON s.station_key = f.station_key
JOIN dim_date d    ON d.date_key    = f.date_key;

-- Q2. Month-over-month change in city-wide average PM2.5
WITH monthly AS (
    SELECT d.[year], d.[month], AVG(f.pm25) AS avg_pm25
    FROM fact_readings f JOIN dim_date d ON d.date_key = f.date_key
    GROUP BY d.[year], d.[month]
)
SELECT [year], [month], ROUND(avg_pm25, 1) AS avg_pm25,
       ROUND(100.0 * (avg_pm25 - LAG(avg_pm25) OVER (ORDER BY [year], [month]))
             / NULLIF(LAG(avg_pm25) OVER (ORDER BY [year], [month]), 0), 1) AS mom_pct_change
FROM monthly
ORDER BY [year], [month];

-- Q3. Ten worst days per station (rank within station)
WITH ranked AS (
    SELECT s.station, d.[date], f.pm25,
           DENSE_RANK() OVER (PARTITION BY f.station_key ORDER BY f.pm25 DESC) AS worst_rank
    FROM fact_readings f
    JOIN dim_station s ON s.station_key = f.station_key
    JOIN dim_date d    ON d.date_key    = f.date_key
    WHERE f.pm25 IS NOT NULL
)
SELECT * FROM ranked WHERE worst_rank <= 10 ORDER BY station, worst_rank;

-- Q4. Gaps-and-islands: longest consecutive runs of "Severe" days (PM2.5 > 250) per station
WITH severe AS (
    SELECT f.station_key, d.[date],
           DATEADD(DAY, -ROW_NUMBER() OVER (PARTITION BY f.station_key ORDER BY d.[date]), d.[date]) AS grp
    FROM fact_readings f JOIN dim_date d ON d.date_key = f.date_key
    WHERE f.pm25 > 250
)
SELECT s.station, MIN([date]) AS streak_start, MAX([date]) AS streak_end, COUNT(*) AS streak_days
FROM severe v JOIN dim_station s ON s.station_key = v.station_key
GROUP BY s.station, v.station_key, grp
HAVING COUNT(*) >= 3
ORDER BY streak_days DESC;
-- NB: this treats a missing day as a break in the streak. A missing day is "unknown", not "clean".
-- Mention that assumption in your report, or fill gaps from a calendar table first.

-- Q5. Share of station-days in each PM2.5 category, by year
SELECT d.[year], f.pm25_category,
       COUNT(*) AS station_days,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (PARTITION BY d.[year]), 1) AS pct_of_year
FROM fact_readings f JOIN dim_date d ON d.date_key = f.date_key
WHERE f.pm25_category IS NOT NULL
GROUP BY d.[year], f.pm25_category
ORDER BY d.[year], pct_of_year DESC;

-- Q6. Weather conditions on severe vs non-severe days (feeds the driver-analysis page)
SELECT CASE WHEN f.pm25 > 250 THEN 'Severe' ELSE 'Not severe' END AS day_type,
       COUNT(*) AS station_days,
       ROUND(AVG(w.wind_kmh), 1)     AS avg_wind_kmh,
       ROUND(AVG(w.humidity_pct), 1) AS avg_humidity,
       ROUND(AVG(w.temp_c), 1)       AS avg_temp_c
FROM fact_readings f JOIN dim_weather w ON w.date_key = f.date_key
WHERE f.pm25 IS NOT NULL
GROUP BY CASE WHEN f.pm25 > 250 THEN 'Severe' ELSE 'Not severe' END;

-- Q7. Year-over-year change for the same month (using LAG with a 12-month offset on a month series)
WITH m AS (
    SELECT d.[year], d.[month], AVG(f.pm25) AS avg_pm25
    FROM fact_readings f JOIN dim_date d ON d.date_key = f.date_key
    GROUP BY d.[year], d.[month]
)
SELECT [year], [month], ROUND(avg_pm25, 1) AS avg_pm25,
       ROUND(100.0 * (avg_pm25 - LAG(avg_pm25, 1) OVER (PARTITION BY [month] ORDER BY [year]))
             / NULLIF(LAG(avg_pm25, 1) OVER (PARTITION BY [month] ORDER BY [year]), 0), 1) AS yoy_pct_change
FROM m
ORDER BY [month], [year];
